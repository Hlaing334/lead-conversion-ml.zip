"""Predicts which enquiries enrol, and tests honestly against a baseline."""
import json, numpy as np, pandas as pd
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.pipeline import make_pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.dummy import DummyClassifier

df = pd.read_csv("leads.csv")
X, y = df.drop(columns="Enrolled"), df["Enrolled"]
cat, num = ["Source","Course"], ["ResponseHours","FollowUps","TrialAttended"]
prep = lambda: ColumnTransformer([("c", OneHotEncoder(), cat), ("n", StandardScaler(), num)])
models = {
 "Baseline (always guess the majority)": DummyClassifier(strategy="prior"),
 "Logistic regression": make_pipeline(prep(), LogisticRegression(max_iter=1000)),
 "Random Forest": make_pipeline(prep(), RandomForestClassifier(300, min_samples_leaf=5, random_state=0)),
}
cv = StratifiedKFold(5, shuffle=True, random_state=0)
out = {}
for name, m in models.items():
    r = cross_validate(m, X, y, cv=cv, scoring=["roc_auc","accuracy"])
    out[name] = (r["test_roc_auc"].mean(), r["test_accuracy"].mean(), r["test_roc_auc"].std())
    print(f"{name:40s} AUC {out[name][0]:.3f} (+/-{out[name][2]:.3f})  accuracy {out[name][1]:.3f}")

rf = models["Random Forest"].fit(X, y)
names = rf[0].get_feature_names_out()
imp = pd.Series(rf[-1].feature_importances_, names).sort_values(ascending=False)
print("\nWhat the Random Forest relies on:"); print((imp.head(5)*100).round(1).to_string())
print("\nEnrolment rate by trial class:"); print(df.groupby("TrialAttended").Enrolled.mean().round(2).to_string())
print("Enrolment rate by source:"); print(df.groupby("Source").Enrolled.mean().round(2).to_string())

# Lead Conversion Prediction (ML)

A small Python project that predicts which student enquiries at a language centre will enrol, and tests honestly whether the model beats a simple baseline.

It is based on work I do at a language centre: contacting enquiries by phone and online and following up with them.

## What it does
1. **Creates data.** `make_data.py` generates 600 **synthetic** enquiries (source, course, hours until we replied, number of follow-ups, whether a trial class was attended, and whether the person enrolled).
2. **Compares models.** `lead_model.py` scores a baseline (always guess the majority), logistic regression and a Random Forest with 5-fold stratified cross-validation, using ROC AUC and accuracy.
3. **Explains the result.** It shows which inputs the Random Forest relies on and the enrolment rate by trial class and by source.

## Results (cross-validated, 5 folds)
| Model | ROC AUC | Accuracy |
|---|---|---|
| Baseline | 0.500 | 0.568 |
| Logistic regression | 0.739 | 0.680 |
| Random Forest | 0.713 | 0.668 |

- Both models clearly beat the baseline (AUC 0.50 means guessing).
- The simpler logistic regression did slightly better than the Random Forest, so a more complex model was not needed.
- Enquiries that attended a trial class enrolled at 63% against 29% for those that did not.
- Response time, trial class and follow-ups were the inputs the Random Forest relied on most.

## Run it
```bash
pip install -r requirements.txt
python make_data.py
python lead_model.py
```

## Limitations
- The data is **synthetic**. I generated it with a hidden rule (trial classes, follow-ups, referrals and faster replies raise enrolment), so the model finding those patterns shows the code works. It does not show what really drives enrolment at any centre.
- 600 rows is small, and the scores vary by about ±0.04 AUC between folds.
- It predicts who is likely to enrol. It does not show that a trial class or a faster reply causes enrolment.

## Ideas to extend it
- Train on real, anonymised enquiry data
- Tune the models properly
- Turn the scores into a ranked follow-up list

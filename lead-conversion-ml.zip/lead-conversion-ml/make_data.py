"""Creates leads.csv: 600 SYNTHETIC enquiries for a language centre."""
import numpy as np, pandas as pd
rng = np.random.default_rng(7)
n = 600
source = rng.choice(["Phone call","Walk-in","Instagram","Referral","Website"], n, p=[.25,.15,.25,.15,.20])
course = rng.choice(["Spoken English","IELTS","Kids English","Business English"], n, p=[.4,.25,.2,.15])
resp_hours = np.round(rng.exponential(10, n).clip(0.2, 72), 1)   # hours until we replied
followups = rng.integers(0, 6, n)
trial = rng.random(n) < 0.45                                       # attended a trial class
# hidden rule used to generate the outcome (the model must rediscover it, noisily)
z = (-1.6 + 1.5*trial + 0.25*followups - 0.03*resp_hours
     + np.where(source=="Referral", .9, 0) + np.where(source=="Walk-in", .6, 0)
     + np.where(course=="IELTS", .3, 0))
p = 1/(1+np.exp(-z))
converted = (rng.random(n) < p).astype(int)
pd.DataFrame(dict(Source=source, Course=course, ResponseHours=resp_hours,
    FollowUps=followups, TrialAttended=trial.astype(int), Enrolled=converted)
  ).to_csv("leads.csv", index=False)
print("rows:", n, " enrolment rate:", round(converted.mean(), 3))
